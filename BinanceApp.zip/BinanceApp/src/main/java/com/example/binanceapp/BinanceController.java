package com.example.binanceapp;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class BinanceController {
    @FXML
    private Label welcomeText;

    // Create an instance of BinanceApiClient
    private BinanceApiClient binanceApiClient = new BinanceApiClient();

    @FXML
    protected void onButtonClick() {
        // Call the fetchDataFromApi method of BinanceApiClient
         binanceApiClient.fetchDataFromApi();
        // Update the welcomeText label with the fetched data

    }
}
