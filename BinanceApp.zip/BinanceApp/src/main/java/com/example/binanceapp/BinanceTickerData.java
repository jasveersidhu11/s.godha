package com.example.binanceapp;

import com.google.gson.annotations.SerializedName;

public class BinanceTickerData {
    // Symbol of the asset pair (e.g., BTCUSDT)
    @SerializedName("symbol")
    public String symbol;
    // Price change in the last 24 hours
    @SerializedName("priceChange")
    public double priceChange;
    // Price change percentage in the last 24 hours
    @SerializedName("priceChangePercent")
    public double priceChangePercent;
    // Add other fields as needed

    // Constructor
    public BinanceTickerData(String symbol, double priceChange, double priceChangePercent) {
        this.symbol = symbol;
        this.priceChange = priceChange;
        this.priceChangePercent = priceChangePercent;
    }

    // Getters and Setters

    /**
     * Get the symbol of the asset pair.
     *
     * @return The symbol of the asset pair.
     */
    public String getSymbol() {
        return symbol;
    }

    /**
     * Set the symbol of the asset pair.
     *
     * @param symbol The symbol of the asset pair.
     */
    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    /**
     * Get the price change in the last 24 hours.
     *
     * @return The price change in the last 24 hours.
     */
    public double getPriceChange() {
        return priceChange;
    }

    /**
     * Set the price change in the last 24 hours.
     *
     * @param priceChange The price change in the last 24 hours.
     */
    public void setPriceChange(double priceChange) {
        this.priceChange = priceChange;
    }

    /**
     * Get the price change percentage in the last 24 hours.
     *
     * @return The price change percentage in the last 24 hours.
     */
    public double getPriceChangePercent() {
        return priceChangePercent;
    }

    /**
     * Set the price change percentage in the last 24 hours.
     *
     * @param priceChangePercent The price change percentage in the last 24 hours.
     */
    public void setPriceChangePercent(double priceChangePercent) {
        this.priceChangePercent = priceChangePercent;
    }

    // Override toString method to provide a meaningful representation of the object
    @Override
    public String toString() {
        return "BinanceTickerData{" +
                "symbol='" + symbol + '\'' +
                ", priceChange=" + priceChange +
                ", priceChangePercent=" + priceChangePercent +
                '}';
    }
}
